#include<iostream>
#include <cmath>
#include<stdio.h>
using namespace std;

				//made by Pinzaru Viacheslav
				//group I1802
				/*Дана  матрица M*М. Определить столбец с минимальнымпроизведением элементов среди столбцов ,
				 содержажзщихтолько такие элементы , которые по модулю не больше наперед заданного числа А*/

	void Fmodul(int *set,int *modul)
		{

			cout <<" \n enter the specified number : ";
			int temp;
			cin >>*set;								//here i set the number modul
			temp = *set;
			*modul = abs(temp);

			cout <<"\n--------------------------------";

			cout <<"\n number : " <<*set <<" ,  mudul number : " << *modul <<" \n";
		}

	void FchArray(int parr[5][5], int *count, int *modul,  int const rows, int const cols)
		{
			int temp = 0;
				for(int i = 0; i < rows; i++)
					{

						for(int j = 0; j < cols; j++)
							{
								if(parr[j][i] <= *modul)		//	   compare each element with the modul
								temp = parr[j][i] * temp;	//	and multiply the numbers
							}
							count[i] = temp;				//	and write it into an array
							temp = 1;
					}

				cout <<"\n--------------------------------";
		}

	void PrintArray(int parr[5][5], int *count, int rows, int cols )
		{
											//here i lead out arrays on screen
			for(int i = 0; i < rows; i++)
				{

					cout <<"\n ";
					for(int j = 0; j < cols; j++)
						{
							printf("%5d",parr[i][j]);
						}
				}

			for(int i = 0; i < cols; i++ )
				cout<<"\n product of numbers in the " << i <<" column = " << count[i] ;
				cout <<"\n--------------------------------";
		}

	void FindMin(int *count, int rows ,int *min)
		{
			int temp = 1;					// here i look for the minimal number
			for(int i = 0; i < rows; i++)	// among columns  calculations
				{
					if(count[i] <= temp)
						{
							temp = count[i];
							*min = i;
						}
				}
			cout <<"\n MIN number = " <<temp <<" of [" << *min <<"] column";

			cout <<"\n--------------------------------";

		}

int main()
{
	int const rows = 5;
	int const cols = 5;
	int modul = 0;
	int set = 0;
	int temp = 1;
	int min;
	int count[cols] = {0};
	int arr[rows][cols] = {{0 ,-17, 2, 5, 3} ,{3 ,5 ,1 ,-3 ,2}, {7, 6, 20, -6, 21}, {3, 8, 6, 18, 8}, {1, 9, 1, 2, -1}};

	cout <<"\n--------------------------------";

	Fmodul(&set, &modul );		//here i set the number modul

	FchArray(arr, count, &modul ,rows, cols);    // here icheck the colums of the array

	PrintArray(arr ,count ,rows,cols);		//here i lead out arrays on screen

	FindMin(count ,rows ,&min); // here i look for the minimal number among columns calculations



}

