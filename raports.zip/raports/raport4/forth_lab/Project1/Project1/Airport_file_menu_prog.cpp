﻿#include <stdio.h>
#include <string>
#include<iostream>
#include<fstream>
#include <cstring>
#include <cmath>
#define LINE 45
#define _eof 30
using namespace std;

//Пынзару Вячеслав 
//группа I-1802
/*Создать файл записей :
<Номер рейса> <Аэропорт назначения> <время вылета> <время прилёта> <цена билета>
Данные для записей программа должна читать из файла ,содержащую информацию в текстовой форме.
Создайте функции :
-	добавления записей в файл;
-	удаления записей ;
-	замену записи;
-	вывод списка городов время лёта в которые превышает определённое время;
-	показа информации изфайла ;
Программа должна содержать меню для управления всеми действиями.	*/
			
void program_menu( void (*f_head)(), void(*f_write)(), void(*f_read)(), void(*f_delete)() , void(*f_change)(), void(*f_certain_time)());
void read_data_from_file();
void head_table();
void write_data_in_file();
void change_data_from_file();
void delete_data_from_file();
void show_airport_flying_over_certain_time();


void program_menu( void (*f_head)(), void(*f_write)(), void(*f_read)(), void(*f_delete)(), void(*f_change)() ,void(*f_certain_time)()){
	int variant = 9;
	int choise = 9;

	
	while(variant != 0){
	variant = 0;
	cout<<"\n***----------------------------------------***\n\n";
	cout<<"[1]	Add information in file 		\n";
	cout<<"[2]	Delete information from file \n";
	cout<<"[3]	Change information in file 	\n";
	cout<<"[4]	Show airport flying over certain time \n";
	cout<<"[5]	Read data from the file \n";
	cout<<"		press ' 0 ' to exit";
	cout<<"\n\n***----------------------------------------***\n\n";
	cout<<"\n choose the option: ";
	cin>>variant;
	switch (variant){
		
		case 1:	cout<<"option 1\n";	
				head_table();
				write_data_in_file();
		break;
		
		case 2:	cout<<"option 2\n";	
				delete_data_from_file();
		break;
		
		case 3:	cout<<"option 3\n";	
				change_data_from_file();
		break;

		case 4:	cout<<"option 4\n";	
				show_airport_flying_over_certain_time();
		break;
		
		case 5:	cout<<"option 5\n";
				head_table();
				read_data_from_file();
		break;
		
		case 6: cout<<"press ' 0 ' to exit";
		break;
		
		default: cout<<"error variant";
		break;
		
	}
		if(variant !=0)
		{
		cout<<"\nselect option: continue [1] or exit [2] ?";
		cin>>choise;

		if(choise == 2)
		{
		variant = 0;}
		}
		system("cls");
		
	}
}

void head_table(){
	
	cout<<"-----------------------------------------------------------------------------------------------------\n";
	cout<<"|    Reis_number     |   Reis_prise  |       Airport_name        |   Timestart     |     Timeout    |\n";
	cout<<"-----------------------------------------------------------------------------------------------------\n";
		 //12345678911234567892123456789312345678941234567895123456789612345678971234567898123456789912345678901
}

void write_data_in_file(){
	char data_string[] = "|                    |               |                           |                 |                |";
	char input_string[30];
	fstream in_out;
	
	cout<<"\n Write data please\n";
	cout<<"\nReis_number ";
	cin.get();
//	fflush();
//	in_out.flush();
	
	cin.getline(input_string, 30);
	for(int i = 0; input_string[i] != '\0';i++  ){
		data_string[i + 8] = input_string[i];
	}
	
		cout<<"\nReis_prise ";
	cin.getline(input_string, 30);
	for(int i = 0; input_string[i] != '\0';i++ ){
		data_string[i + 27] = input_string[i];
	}
	
		cout<<"\nAirport_name ";
	cin.getline(input_string, 30);
	for(int i = 0; input_string[i] != '\0';i++ ){
		data_string[i + 47] = input_string[i];
	}
	
		cout<<"\nTimestart ";
	cin.getline(input_string, 30);
	for(int i = 0; input_string[i] != '\0';i++ ){
		data_string[i + 72] = input_string[i];
	}
	
		cout<<"\nTimeout ";
	cin.getline(input_string, 30);
	for(int i = 0; input_string[i] != '\0';i++ ){
		data_string[i + 90] = input_string[i];
	}
	cout<<data_string;

	
	in_out.open("airport1.txt",ios::app);
//	in_out<<"-----------------------------------------------------------------------------------------------------\n";
	in_out<<data_string<<"\n";
//	in_out<<"-----------------------------------------------------------------------------------------------------\n";
	in_out.close();
}



void read_data_from_file(){
	char lines[LINE][103];  // 200 stroc ,dlinnoi kajdaia v 102 simvola (V)
	fstream in_out;		 // 200 slov dlinnoi v 102 simvola (X)
	int count = 0;
			
	in_out.open("airport1.txt",ios::in);
//	in_out.get();
	while(!in_out.eof())
	{	
				// tut ia scitivaiu iz faila cajduiu strocu  dlinnoi v 102 simvola
		in_out.getline(lines[count],102,'\n'); //zapolneaet 1 string dlinoi v 102 simvola
		count++;
	}
	in_out.close();
	
	for(int i = 0; i<count; i++)
	{
		cout<<lines[i] <<"\n";
	}
//	cout<<"|                                                                                                   |\n";
//	cout<<"-----------------------------------------------------------------------------------------------------\n";

	
}


void delete_data_from_file()
{

	int delete_string = 0;
	char lines[LINE][110];
	int count = 1;
	fstream in_out;
	
	cout<<"Write string which will be deleted :";
	cin>>delete_string; cout<<"\n";

	in_out.open("airport1.txt",ios::in);
	while(!in_out.eof())
	{
		in_out.getline(lines[count] , 110);
		count++;
	}
	in_out.close();

	count -=2;

	in_out.open("airporttest.txt",ios::out);
	for(int i = 1;i<=count;i++)
	{
		if(delete_string != i)
		{cout<<i;
		cout<<lines[i] <<"\n";
		in_out<<lines[i]<<"\n";

		}
		else
		cout<<"***String ["<<i <<"] has just deleted***" <<"\n";
					
	}

	in_out.close();
	remove("airport1.txt");
	rename("airporttest.txt","airport1.txt");

}

void change_data_from_file(){
	int change_string = 2;
	char lines[LINE][102];
	char data_string[] = "|                    |               |                           |                 |                |";
	char input_string[30];
	int count = 1;
	
	cout<<"Write string which will be changed :";
	cin>>change_string; cout<<"\n";
	fstream in_out;
	in_out.open("airport1.txt", ios::in);
	while(!in_out.eof())
	{
		in_out.getline(lines[count],102);
		count++;
	}
	
	in_out.close();
	count -=2;
	in_out.open("airporttest.txt",ios::out);
	for(int j = 1; j<= count; j++)
	{
		if(change_string != j)
		{
			cout<<j;
			cout<<lines[j]<<"\n";
			in_out<<lines[j]<<"\n";
		}
		else
		{
				cout<<"***String ["<<change_string <<"] is changing now***" <<"\n";
			
					cout<<"\n Write data please\n";
					cout<<"\nReis_number";
					cin.get();
				//	fflush();
				//	in_out.flush();
				
					cin.getline(input_string, 30);
					for(int i = 0; input_string[i] != '\0';i++  ){
						data_string[i + 8] = input_string[i];
					}
					
						cout<<"\nReis_prise";
					cin.getline(input_string, 30);
					for(int i = 0; input_string[i] != '\0';i++ ){
						data_string[i + 27] = input_string[i];
					}
					
						cout<<"\nAirport_name";
					cin.getline(input_string, 30);
					for(int i = 0; input_string[i] != '\0';i++ ){
						data_string[i + 47] = input_string[i];
					}
					
						cout<<"\nTimestart";
					cin.getline(input_string, 30);
					for(int i = 0; input_string[i] != '\0';i++ ){
						data_string[i + 72] = input_string[i];
					}
					
						cout<<"\nTimeout";
					cin.getline(input_string, 30);
					for(int i = 0; input_string[i] != '\0';i++ ){
						data_string[i + 90] = input_string[i];
					}
//					cout<<change_string;
					cout<<data_string<<"\n";

			
			in_out<<data_string<<"\n";
		}
	}
	in_out.close();
	remove("airport1.txt");
	rename("airporttest.txt","airport1.txt");
}

void show_airport_flying_over_certain_time(){
	char line[256];
	int certain_hours = 0;
	int certain_minutes = 0;
	int count_hours;
	int count_minutes;
	fstream in_out;
	
	cout<<" \n write hours: ";
	cin >>certain_hours; 
	cout<<" \n write minutes: ";
	cin>>certain_minutes;
	cout<<"\n\tIn this cities flying time exceeds "; printf("%d:",certain_hours); printf("%.2d",certain_minutes); cout<<" :\n";
	
	in_out.open("airport1.txt",ios::in);
	while(!in_out.eof())
	{
		in_out.getline(line,256);
		if(line[0] != '\0')
		{


		int hours_start = 0;
		int minutes_start = 0;
		if(line[72] == ' ') hours_start = 0;
		else if(line[72] == '1') hours_start = 10;
		else if(line[72] == '2') hours_start = 20;
		
		hours_start += line[73] - '0';
		minutes_start = 10*(line[75] - '0');
		minutes_start += line[76] - '0';
		
//		cout<<hours_start<<":"<<minutes_start<<"\n";
		
		int hours_out = 0;
		int minutes_out = 0;
		
		if(line[90] =='0') hours_out = 0;
		else if(line[90] == '1') hours_out = 10;
		else if(line[90] == '2') hours_out = 20;
		
		hours_out += line[91] - '0';
		minutes_out = 10 * (line[93] - '0');
		minutes_out += line[94] - '0';		
//		cout<<hours_out<<":"<<minutes_out<<"\n";
		
		count_hours = hours_start - hours_out;
		count_minutes = minutes_start - minutes_out;
			if( (abs(count_hours) >= certain_hours) )
				if( (abs(count_minutes) >= count_minutes) )
					cout<<line<<"\n";

		}
		
	}
	in_out.close();
	cout<<line;
	
	
}

int main()
{

	program_menu(	head_table, write_data_in_file, read_data_from_file, delete_data_from_file , change_data_from_file, show_airport_flying_over_certain_time);

		
	return 0;	
}

//
//void delete_information_from_file(){
//	int select_string;
//	int number;
//	fstream in_out;
//	char temp = '\n';
//	FILE *ptr;
//	int count=0;
////	ptr = fopen("airport1.txt","r+");
//
//	in_out.open("airport1.txt",ios::in | ios::out);
//	cout<<"\n write string which will delete :";
//	cin>>select_string;
//	for( int i = 0; i<LINE ;i++)
//	{
//
//
//		in_out.seekg(2 , ios::beg);
//		
////		in_out.get(temp);
////		in_out.get(temp);
////		in_out.put(temp);
//	//	in_out<<"\n";
//		in_out>>number;
////		in_out.get(temp);
//		
////		fscanf(ptr,"\n        %d ", &number);
//		
//	
//		if(number == select_string)
//			{
//				while( count<103)
//				{
//				in_out.get(temp);
////						in_out.put(temp);
//
//				count++;	
//				}
////				in_out<<">>>";
////				fprintf(ptr ,">>>");
//			}
//	}
//	
//	in_out.close();	
////	fclose(ptr);
//}
