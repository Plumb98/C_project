#include<iostream>
#include <cmath>
#include "stdio.h"

using namespace std;

				//made by Pinzaru Viacheslav
				//group I1802
				//5.27
    /* Дана  матрица M*М. Определить столбец с минимальнымпроизведением элементов
    среди столбцов , содержажзщихтолько такие элементы ,
    которые по модулю не больше наперед заданного числа А*/
int main()
{
	int const rows = 5;
	int const cols = 5;
	int set = 0;
	int temp = 1;
	int min;
	int count[cols] = {0};
	int arr[rows][cols] = {{0 ,-17, 2, 5, 3} ,{3 ,5 ,1 ,-3 ,2}, {7, 6, 20, -6, 21}, {3, 8, 6, 18, 8}, {1, 9, 1, 2, -1}};


	cout <<"\n--------------------------------";
													//here i set the number modul
	cout <<" \n enter the specified number : ";
	cin >>set;
	cout <<"\n number : " <<set <<" ,  mudul number : " << abs(set) <<" \n";
		int modul = abs(set);

	cout <<"\n--------------------------------";
												// here icheck the colums of the array
	for(int i = 0; i < rows; i++)
		{

			for(int j = 0; j < cols; j++)
				{
					if(arr[j][i] <= modul)		//	   compare each element with the modul
					temp = arr[j][i] * temp;	//		and multiply the numbers
				}
				count[i] = temp;				//	and write it into an array
				temp = 1;
		}

	cout <<"\n--------------------------------";
												//here i lead out arrays on screen
	for(int i = 0; i < rows; i++)
		{

			cout <<"\n ";
			for(int j = 0; j < cols; j++)
				{
					printf("%5d",arr[i][j]);
				}
		}


	for(int i = 0; i < cols; i++ )
		cout<<"\n product of numbers in the " << i <<" column = " << count[i] ;

	cout <<"\n--------------------------------";
												// here i look for the minimal number
	for(int i = 0; i < rows; i++)				// among columns  calculations
		{
			if(count[i] <= temp)
				{
					temp = count[i];
					min = i;
				}
		}
	cout <<"\n MIN number = " <<temp <<" of [" << min <<"] column";

	cout <<"\n--------------------------------";

	return 0;
}



//-

//	srand(time(NULL));


//	    for (int i = 0; i < m; i++)
//    		{
//     	   		for (int j = 0; j < n; j++)
//       				{
//            			mas[i][j] =  rand();
//            			sum = sum + mas[i][j];
//        			}
//    		}


//	    for (int i = 0; i < m; i++)
//	    		{
//	     	   		for (int j = 0; j < n; j++)
//	       				{
//	            			cout << mas[i][j] << " ";
//	        			}
//	        		 cout<<endl;
//	    		}
//




    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

//    	int m = 4;
//	int n = 3;
//	int mas[n][m];
//    int sum = 0;
//	int d = 0;
//	int j = 0;
//	for(int i = 0; i < 3; i++)
//		{
//			for(j=0; j < 4; j++)
//				d++;
//				mas[i][j] = d;
//
//		}
//
//cout <<"\n-------------------------------";
//
//
//    for(int i = 0; i < 3; i++)
//		{
//				cout <<"\n";
//			for(int j = 0; j < 4; j++)
//				{
//					cout <<"   " <<mas[i][j];
//				}
//
//		}
//
//===================================
//	for(int i = 0; i < rows; i++)
//		{
//
//			for(int j = 0; j < cols; j++)
//				{
//					if(arr[j][i] <= modul)
//					arr[j][i] = arr[j][i]+100;
////					if(arr[i][j] <= modul)
////						{
////												for(int n = i; n < rows; n++)
////													{
////														if(arr[i][j] <=modul)
////															{
////																temp = arr[i][j]
////															}
////													}
////						}
//				}
//		}

//					arr[j][i] = arr[j][i]+100;
//					if(arr[i][j] <= modul)
//						{
//												for(int n = i; n < rows; n++)
//													{
//														if(arr[i][j] <=modul)
//															{
//																temp = arr[i][j]
//															}
//													}
//						}
