#include <stdio.h>
#include <string>
#include<iostream>
#include <cstring>
#include <cmath>
#include "Header.h"

using namespace std; 



void show_airport_with_certain_time(airinfo mas[], int size){
	char airport_namecity[20];	//= "Chisinau";
	time certain_time;			//= {18 , 00};
	cout << " \n write airport_name:";
	cin >> airport_namecity;
	cout << " \n write hours: ";
	cin >> certain_time.hours;
	cout << " \n write minutes: ";
	cin >> certain_time.minutes;

	cout << "\n\tIn the " << airport_namecity << "  after  " << certain_time.hours << ":"; printf("%.2d", certain_time.minutes); cout << "  will came ,next reises: ";
	for (int i = 0; i < size; i++)
	{
		if (!(strcmp(airport_namecity, mas[i].airport_name)))
		{
			if ((certain_time.hours < mas[i].timeout.hours) || ((certain_time.hours == mas[i].timeout.hours) && (certain_time.minutes < mas[i].timeout.minutes)))
			{
				cout << "\n No[" << mas[i].reis_number << "] " << mas[i].airport_name << " reis_prise: ";
				cout << mas[i].reis_prise << " time coming: " << mas[i].timeout.hours << ":" << mas[i].timeout.minutes;
			}
		}
	}
	cout << "\n\n\t*** next instruction ***\n\n";
}