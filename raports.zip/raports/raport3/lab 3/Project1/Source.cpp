﻿#include <stdio.h>
#include <string>
#include<iostream>
#include <cstring>
#include <cmath>
#include "Header.h"

using namespace std;

/* Вариант 7 
	создвйте массив структур из 10и элементов
	(номер рейса)  (вэропорт назначения) (время  вылета) (время прилета) (цена билета)
	1) Выберите рейсы прибывающие в Город (Кишинёв) после 18:00 
	2) Покажите города время лёта в которые превышает дав часа*/


int main()
{
	const int size = 10;
	airinfo data[size];
	FILE *ptrf;

	//	ptrf = fopen("airport2.txt","w");
	//	write_data_in_file(data,size,ptrf);
	//	fclose(ptrf);

	ptrf = fopen("airport2.txt", "r");
	if (ptrf != NULL)
		read_data_from_file(data, size, ptrf);
	else printf("\n -1");
	fclose(ptrf);

	show_airport_with_certain_time(data, size);
	show_airport_flying_over_certain_time(data, size);

	system("pause");
}



