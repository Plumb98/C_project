#include <stdio.h>
#include <string>
#include<iostream>
#include <cstring>
#include <cmath>
#include "Header.h"

using namespace std; 

void write_data_in_file(airinfo mas[], int size, FILE *ptr);

void write_data_in_file(airinfo mas[], int size, FILE *ptr){
	cout << "List with data with [" << size << "] elements:\n";
	for (int i = 0; i < size; i++)
	{
		cout << "write data in list number" << i << "\n"; cout << " ";
		cout << "reis_number "; cin >> mas[i].reis_number;
		cout << "reis_prise "; cin >> mas[i].reis_prise;
		cout << "airport_name "; cin >> mas[i].airport_name;
		cout << "timestart.hours "; cin >> mas[i].timestart.hours;
		cout << "timestart.minutes "; cin >> mas[i].timestart.minutes;
		cout << "timeout.hours "; cin >> mas[i].timeout.hours;
		cout << "timeout.minutes "; cin >> mas[i].timeout.minutes;
		cout << "finish\n";
	}
	for (int i = 0; i < size; i++)
	{
		fprintf(ptr, "%d %.2f %s ", mas[i].reis_number, mas[i].reis_prise, mas[i].airport_name);
		fprintf(ptr, "%d %d %d %d\n", mas[i].timestart.hours, mas[i].timestart.minutes, mas[i].timeout.hours, mas[i].timeout.minutes);
	}
	//	for(int i = 0;i < size;i++)
	//	{
	//		fprintf(ptr,"%d %d %s %d %d %d %d\n",mas[i].reis_number, mas[i].reis_prise, mas[i].airport_name,mas[i].timestart.hours, mas[i].timestart.minutes, mas[i].timeout.hours, mas[i].timeout.minutes);
	//	}		
}