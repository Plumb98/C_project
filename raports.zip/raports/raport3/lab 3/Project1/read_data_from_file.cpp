#include <stdio.h>
#include <string>
#include<iostream>
#include <cstring>
#include <cmath>
#include "Header.h"

using namespace std;

void read_data_from_file(airinfo mas[], int size, FILE *ptr);

void read_data_from_file(airinfo mas[], int size, FILE *ptr){
	cout << "List with data with [" << size << "] elements:\n";
	for (int i = 0; i < size; i++)
	{
		fscanf(ptr, "%d %f %s", &(mas[i].reis_number), &(mas[i].reis_prise), mas[i].airport_name);
		fscanf(ptr, "         %d %d %d %d\n", &(mas[i].timestart.hours), &(mas[i].timestart.minutes), &(mas[i].timeout.hours), &(mas[i].timeout.minutes));
	}

	for (int i = 0; i < size; i++)
	{
		printf("\n   Reis_number: %d\t reis_prise: %.2f\t airport_name: %14s   ", mas[i].reis_number, mas[i].reis_prise, mas[i].airport_name);
		printf("timestart: %d:%d   timeout: %d:%d\n", mas[i].timestart.hours, mas[i].timestart.minutes, mas[i].timeout.hours, mas[i].timeout.minutes);
	}
	cout << "\n\n\t*** next instruction ***\n\n";
}