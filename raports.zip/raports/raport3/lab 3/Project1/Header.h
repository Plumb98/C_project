

struct time{
	int hours;
	int minutes;
};

struct airinfo {
	int reis_number;
	float reis_prise;
	char airport_name[20];
	time timestart;
	time timeout;

};

void read_data_from_file(airinfo mas[], int size, FILE *ptr);
void write_data_in_file(airinfo mas[], int size, FILE *ptr);
void show_airport_with_certain_time(airinfo mas[], int size);
void show_airport_flying_over_certain_time(airinfo mas[], int size);

