#include <stdio.h>
#include <string>
#include<iostream>
#include <cstring>
#include <cmath>
#include "Header.h"

using namespace std; 


void show_airport_flying_over_certain_time(airinfo mas[], int size){
	time certain_time; //= {2 , 0};
	int temp;//= 0;
	cout << " \n write hours: ";
	cin >> certain_time.hours;
	cout << " \n write minutes: ";
	cin >> certain_time.minutes;
	cout << "\n\tIn this cities flying time exceeds "; printf("%d:", certain_time.hours); printf("%.2d", certain_time.minutes); cout << " :\n";
	for (int i = 0; i < size; i++)
	{
		temp = mas[i].timestart.hours - mas[i].timeout.hours;
		if (abs(temp) >= 2)
			cout << "\n\tNo[" << mas[i].reis_number << "] " << mas[i].airport_name << " reis_prise: " << mas[i].reis_prise;
	}
	cout << "\n\n\t*** next instruction ***\n\n";
}